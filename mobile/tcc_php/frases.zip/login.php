<?php
require_once 'config.php';

// Recebe JSON corretamente
$data = json_decode(file_get_contents("php://input"), true);

// Se veio vazio, tenta pegar do $_POST (fallback)
if (!$data) {
    $data = $_POST;
}

if (!isset($data['email']) || !isset($data['senha'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Dados obrigatórios faltando'
    ]);
    exit();
}

$email = $conn->real_escape_string($data['email']);
$senha = $data['senha']; // Não escapa senha antes do verify

$sql = "SELECT * FROM usuarios WHERE email = '$email'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $usuario = $result->fetch_assoc();
    
    // Verifica a senha
    if (password_verify($senha, $usuario['senha'])) {
        // Remove a senha antes de enviar
        unset($usuario['senha']);
        echo json_encode([
            'success' => true,
            'usuario' => $usuario
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Senha incorreta'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Usuário não encontrado'
    ]);
}

$conn->close();
?>