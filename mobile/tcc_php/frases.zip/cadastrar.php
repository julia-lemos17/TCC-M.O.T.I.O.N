<?php
require_once 'config.php';

// Recebe JSON corretamente
$data = json_decode(file_get_contents("php://input"), true);

// DEBUG - Remove após testar
file_put_contents("debug_cadastro.txt", date('Y-m-d H:i:s') . " - " . json_encode($data) . "\n", FILE_APPEND);

// Validação
if (!isset($data['email']) || !isset($data['senha']) || !isset($data['nome'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Dados obrigatórios faltando',
        'recebido' => $data
    ]);
    exit();
}

// Verifica se email já existe
$email_check = $conn->real_escape_string($data['email']);
$check_sql = "SELECT id_usuario FROM usuarios WHERE email = '$email_check'";
$check_result = $conn->query($check_sql);

if ($check_result && $check_result->num_rows > 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Este email já está cadastrado'
    ]);
    exit();
}

// Dados
$email = $conn->real_escape_string($data['email']);
$senha = $data['senha']; // Não escapa antes do hash
$nome = $conn->real_escape_string($data['nome']);
$nome_dependente = isset($data['nome_dependente']) ? $conn->real_escape_string($data['nome_dependente']) : null;

$senhaHash = password_hash($senha, PASSWORD_DEFAULT);

// INSERT
$sql = "INSERT INTO usuarios (email, senha, nome, nome_dependente) VALUES ('$email', '$senhaHash', '$nome', " . ($nome_dependente ? "'$nome_dependente'" : "NULL") . ")";

if ($conn->query($sql) === TRUE) {
    $id = $conn->insert_id;
    echo json_encode([
        'success' => true, 
        'message' => 'Cadastro realizado com sucesso',
        'id_usuario' => $id
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao cadastrar: ' . $conn->error
    ]);
}

$conn->close();
?>