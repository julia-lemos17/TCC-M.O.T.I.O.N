<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    // Buscar falas por categoria
    if (isset($data['id_categoria'])) {
        $id_categoria = $conn->real_escape_string($data['id_categoria']);
        $sql = "SELECT id_fala, texto, emoji FROM falas WHERE id_categoria = '$id_categoria' ORDER BY ordem, id_fala";
        $result = $conn->query($sql);

        $falas = [];
        if ($result && $result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $falas[] = $row;
            }
        }
        echo json_encode(['success' => true, 'falas' => $falas]);

    // Registrar no histórico
    } elseif (isset($data['id_usuario']) && isset($data['id_fala'])) {
        $id_usuario = $conn->real_escape_string($data['id_usuario']);
        $id_fala = $conn->real_escape_string($data['id_fala']);
        
        // Busca o texto e emoji da fala
        $busca = $conn->query("SELECT texto, emoji FROM falas WHERE id_fala = '$id_fala'");
        $fala = $busca->fetch_assoc();
        
        $sql = "INSERT INTO historico_comunicacao (usuario_id, id_fala, texto, emoji) 
                VALUES ('$id_usuario', '$id_fala', '{$fala['texto']}', '{$fala['emoji']}')";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'message' => 'Fala registrada no histórico']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao registrar fala: ' . $conn->error]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Parâmetros inválidos para falas.php']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
}

$conn->close();
?>