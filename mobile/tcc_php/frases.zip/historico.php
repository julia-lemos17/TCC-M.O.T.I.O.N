<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['usuario_id'])) {
            $usuario_id = $conn->real_escape_string($_GET['usuario_id']);
            // CORRIGIDO: historico_comunicacao
            $sql = "SELECT h.id_historico, h.data_uso, h.texto, h.emoji, f.texto as fala_texto, c.nome_categoria 
                    FROM historico_comunicacao h
                    LEFT JOIN falas f ON h.id_fala = f.id_fala
                    LEFT JOIN categorias c ON f.id_categoria = c.id_categoria
                    WHERE h.usuario_id = '$usuario_id'
                    ORDER BY h.data_uso DESC
                    LIMIT 100";
            $result = $conn->query($sql);

            $historico = [];
            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $historico[] = [
                        'id_historico' => $row['id_historico'],
                        'data_uso' => $row['data_uso'],
                        'texto' => $row['texto'] ?? $row['fala_texto'] ?? '',
                        'emoji' => $row['emoji'] ?? '💬',
                        'nome_categoria' => $row['nome_categoria'] ?? 'Comunicação'
                    ];
                }
            }
            echo json_encode(['success' => true, 'historico' => $historico]);
        } else {
            echo json_encode(['success' => false, 'message' => 'usuario_id é obrigatório']);
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data || !isset($data['usuario_id'])) {
            echo json_encode(['success' => false, 'message' => 'usuario_id é obrigatório']);
            exit();
        }
        $usuario_id = $conn->real_escape_string($data['usuario_id']);

        $sql = "DELETE FROM historico_comunicacao WHERE usuario_id = '$usuario_id'";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'message' => 'Histórico limpo']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao limpar histórico: ' . $conn->error]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Método não permitido']);
        break;
}

$conn->close();
?>