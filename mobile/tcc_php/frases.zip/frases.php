<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['usuario_id'])) {
            $usuario_id = $conn->real_escape_string($_GET['usuario_id']);
            // CORRIGIDO: frases_personalizadas
            $sql = "SELECT id_frase, texto FROM frases_personalizadas WHERE usuario_id = '$usuario_id' ORDER BY data_criacao DESC";
            $result = $conn->query($sql);

            $frases = [];
            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $frases[] = $row;
                }
            }
            echo json_encode(['success' => true, 'frases' => $frases]);
        } else {
            echo json_encode(['success' => false, 'message' => 'usuario_id é obrigatório']);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data || !isset($data['usuario_id']) || !isset($data['texto'])) {
            echo json_encode(['success' => false, 'message' => 'usuario_id e texto são obrigatórios']);
            exit();
        }
        $usuario_id = $conn->real_escape_string($data['usuario_id']);
        $texto = $conn->real_escape_string($data['texto']);

        $sql = "INSERT INTO frases_personalizadas (usuario_id, texto) VALUES ('$usuario_id', '$texto')";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'message' => 'Frase adicionada', 'id_frase' => $conn->insert_id]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao adicionar frase: ' . $conn->error]);
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data || !isset($data['id_frase'])) {
            echo json_encode(['success' => false, 'message' => 'id_frase é obrigatório']);
            exit();
        }
        $id_frase = $conn->real_escape_string($data['id_frase']);

        $sql = "DELETE FROM frases_personalizadas WHERE id_frase = '$id_frase'";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'message' => 'Frase deletada']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao deletar frase: ' . $conn->error]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Método não permitido']);
        break;
}

$conn->close();
?>