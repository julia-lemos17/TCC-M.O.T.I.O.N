<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['usuario_id']) && isset($_GET['dia_semana'])) {
            $usuario_id = $conn->real_escape_string($_GET['usuario_id']);
            $dia_semana = $conn->real_escape_string($_GET['dia_semana']);
            // CORRIGIDO: rotinas (plural) ao invés de rotina
            $sql = "SELECT id_rotina, atividade, horario FROM rotinas WHERE usuario_id = '$usuario_id' AND dia_semana = '$dia_semana' ORDER BY horario";
            $result = $conn->query($sql);

            $rotinas = [];
            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $rotinas[] = $row;
                }
            }
            echo json_encode(['success' => true, 'rotinas' => $rotinas]);
        } else {
            echo json_encode(['success' => false, 'message' => 'usuario_id e dia_semana são obrigatórios']);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data || !isset($data['usuario_id']) || !isset($data['dia_semana']) || !isset($data['atividade'])) {
            echo json_encode(['success' => false, 'message' => 'usuario_id, dia_semana e atividade são obrigatórios']);
            exit();
        }
        $usuario_id = $conn->real_escape_string($data['usuario_id']);
        $dia_semana = $conn->real_escape_string($data['dia_semana']);
        $atividade = $conn->real_escape_string($data['atividade']);
        $horario = isset($data['horario']) ? "'" . $conn->real_escape_string($data['horario']) . "'" : 'NULL';

        $sql = "INSERT INTO rotinas (usuario_id, dia_semana, atividade, horario) VALUES ('$usuario_id', '$dia_semana', '$atividade', $horario)";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'message' => 'Rotina adicionada', 'id_rotina' => $conn->insert_id]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao adicionar rotina: ' . $conn->error]);
        }
        break;

    case 'DELETE':
        $data = json_decode(file_get_contents("php://input"), true);
        if (!$data || !isset($data['id_rotina'])) {
            echo json_encode(['success' => false, 'message' => 'id_rotina é obrigatório']);
            exit();
        }
        $id_rotina = $conn->real_escape_string($data['id_rotina']);

        $sql = "DELETE FROM rotinas WHERE id_rotina = '$id_rotina'";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(['success' => true, 'message' => 'Rotina deletada']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao deletar rotina: ' . $conn->error]);
        }
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Método não permitido']);
        break;
}

$conn->close();
?>